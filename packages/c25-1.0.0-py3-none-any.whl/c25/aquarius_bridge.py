import urllib.request, json
from pathlib import Path
from datetime import datetime

def bridge():
    AQUARIUS_API = "https://aquarius.opensea.io/api/v2/chains/1/collections"
    IPC_DIR = Path.home()/"c25_ipc/pending"
    IPC_DIR.mkdir(parents=True, exist_ok=True)
    print("[*] Fetching live index from Aquarius...")
    try:
        with urllib.request.urlopen(AQUARIUS_API, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        print(f"[+] Fetched {len(data)} entries.")
    except Exception as e:
        print(f"[!] Failed to reach Aquarius: {e}")
        return
    task_payload = {
        "task_id": f"aquarius_ingest_{datetime.now().strftime(