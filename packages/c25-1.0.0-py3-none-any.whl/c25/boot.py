import time, subprocess, sys

def main():
    print("[C25 Boot] Starting orchestrator loop...")
    while True:
        try:
            subprocess.run([sys.executable, "-m", "c25.consume_ipc"], check=False)
        except Exception as e:
            print(f"[error] {e}")
        time.sleep(15)

if __name__ == "__main__":
    main()
