/**
 * VideoCourts™ — Public Release v1.0.0
 * Judicial Session Console — Chain-Aware · Biometric-Bound · Court-Grade
 *
 * Merged from:
 *   - Constellation25/repos/videocourts/frontend/ (React frontend)
 *   - VideoCourts-WebSocket-Complete/ (WS hooks)
 *   - VideoCourts-Video/ (Jitsi / Daily / SimpleWebRTC rooms)
 *   - backups/VideoCourts_1776349635/ (canonical backup)
 *   - VideoCourts_Compiled/VideoCourts_Master_Compilation.md
 *   - constellation25-ecosystem/agents/VideoCourts_Structure.json
 *
 * Deploy: Vercel / Netlify / GitHub Pages (static export)
 * Backend: FastAPI on port 8080 (Mars agent) or standalone mode
 *
 * © 2024-2026 FacePrintPay Inc / Kre8tive Holdings — All rights reserved
 */

import { useState, useEffect, useRef, useCallback, createContext, useContext } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS & CONFIG
// ─────────────────────────────────────────────────────────────────────────────
const APP_VERSION  = "1.0.0";
const BUILD_ID     = "VC-PUBLIC-20260906";
const NODE_ID      = "VC-ND-07";
const WS_URL       = typeof window !== "undefined"
  ? `${window.location.protocol === "https:" ? "wss" : "ws"}://${window.location.host}/ws`
  : "ws://localhost:8080/ws";

const VIDEO_PROVIDERS = ["SimpleWebRTC", "Jitsi", "Daily.co"];

// ─────────────────────────────────────────────────────────────────────────────
// MOCK DATA  (replaced by API in production)
// ─────────────────────────────────────────────────────────────────────────────
const SESSIONS_INIT = [
  { id:"s1", caseNumber:"CR-24-1087", title:"State v. Dalton",     status:"live",      type:"Arraignment",      mode:"Remote",    time:"09:00", elapsed:0, judge:"Hon. Martinez", clerk:"R. Chen",  circuit:"3rd Judicial Circuit", courtroom:"4B",  recording:true,  remote:true,   legyc:true,  biometric:"Verified", nextMatter:"State v. Jordan (09:45)", participants:["Hon. Martinez","R. Chen","Def. Dalton","Att. Johnson","Att. Rivera"], notes:"Defendant appearing via remote secure link." },
  { id:"s2", caseNumber:"CR-24-1122", title:"State v. Jordan",     status:"scheduled", type:"Bond Review",       mode:"JailCourt", time:"09:45", elapsed:0, judge:"Hon. Martinez", clerk:"R. Chen",  circuit:"3rd Judicial Circuit", courtroom:"4B",  recording:false, jailcourt:true,               biometric:"Pending",   participants:["Hon. Martinez","Def. Jordan","Att. Williams"],         notes:"Defendant in custody. Biometric pending." },
  { id:"s3", caseNumber:"CV-24-0198", title:"Smith v. Ortega",     status:"scheduled", type:"Civil Motion",      mode:"Live",      time:"10:30", elapsed:0, judge:"Hon. Martinez", clerk:"T. Park", circuit:"3rd Judicial Circuit", courtroom:"4B",  recording:false, remote:true,                  biometric:"N/A",       participants:["Hon. Martinez","T. Park","Att. Smith","Att. Ortega"], notes:"Motion for summary judgment." },
  { id:"s4", caseNumber:"EDU-24-0003",title:"Mock: Rivera v. State",status:"mock",     type:"Training",          mode:"Remote",    time:"11:30", elapsed:0, judge:"AI Trainer",    clerk:"—",       circuit:"Mock Trial Lab",       courtroom:"EDU-1",recording:false,mock:true,                    biometric:"N/A",       participants:["AI Trainer","Student A","Student B"],                  notes:"Law school training session." },
];

const CASES_INIT = [
  { id:"c1", caseNumber:"CR-24-1087", title:"State v. Dalton",   status:"active", type:"Criminal", filed:"2024-01-15", judge:"Hon. Martinez", circuit:"3rd Judicial Circuit", docket:12, attorneys:["Att. Johnson","Att. Rivera"] },
  { id:"c2", caseNumber:"CR-24-1122", title:"State v. Jordan",   status:"active", type:"Criminal", filed:"2024-02-01", judge:"Hon. Martinez", circuit:"3rd Judicial Circuit", docket:8,  attorneys:["Att. Williams"] },
  { id:"c3", caseNumber:"CV-24-0198", title:"Smith v. Ortega",   status:"active", type:"Civil",    filed:"2024-01-28", judge:"Hon. Martinez", circuit:"3rd Judicial Circuit", docket:21, attorneys:["Att. Smith","Att. Ortega"] },
  { id:"c4", caseNumber:"CR-23-0991", title:"State v. Webb",     status:"closed", type:"Criminal", filed:"2023-11-10", judge:"Hon. Chen",     circuit:"3rd Judicial Circuit", docket:34, attorneys:["Att. Moore"] },
  { id:"c5", caseNumber:"FAM-24-0044",title:"Brooks v. Brooks",  status:"active", type:"Family",   filed:"2024-03-02", judge:"Hon. Johnson",  circuit:"Family Court",         docket:5,  attorneys:["Att. Brooks","Att. Lee"] },
];

const EVIDENCE_INIT = [
  { id:"e1", caseId:"c1", caseNumber:"CR-24-1087", fileName:"evidence_video.mp4",     hash:"a3f5d8c2e1b9f4a7c6e2d1f8a9b3c5e7d4f6a8b2c9e3d1f5a7c4b6e8d2f9a1c3", uploadedBy:"Officer Davis",  status:"verified", size:"24.5 MB", uploadDate:"2025-02-14", type:"video",    chain:"Confirmed" },
  { id:"e2", caseId:"c1", caseNumber:"CR-24-1087", fileName:"witness_statement.pdf",  hash:"b4f6e9d3c2a1e5f7b8c9d2e1a3f4b5c6e7d8f9a2b3c4e5f6a7b8c9d0e1f2a3b4", uploadedBy:"Att. Johnson",   status:"verified", size:"1.2 MB",  uploadDate:"2025-02-15", type:"document", chain:"Confirmed" },
  { id:"e3", caseId:"c2", caseNumber:"CR-24-1122", fileName:"booking_photo.jpg",       hash:"c5d7f9a1b3e5c7d9f1a3b5c7d9e1a3c5f7b9d1f3a5c7e9b1d3f5a7c9e1b3d5f7", uploadedBy:"Det. Rodriguez", status:"verified", size:"0.8 MB",  uploadDate:"2025-02-01", type:"image",    chain:"Confirmed" },
  { id:"e4", caseId:"c3", caseNumber:"CV-24-0198", fileName:"contract_exhibit_A.pdf",  hash:"d6e8f0a2b4c6d8e0f2a4b6c8d0e2f4a6b8c0d2e4f6a8b0c2d4e6f8a0b2c4d6e8", uploadedBy:"Att. Smith",     status:"pending",  size:"3.4 MB",  uploadDate:"2025-03-01", type:"document", chain:"Pending" },
];

const NOTIFICATIONS_INIT = [
  { id:"n1", level:"warn",    type:"biometric", message:"Biometric verification pending: State v. Jordan (09:45)", time:"08:52", read:false },
  { id:"n2", level:"info",    type:"filing",    message:"CM/ECF: 3 new filings queued for CR-24-1087",             time:"08:57", read:false },
  { id:"n3", level:"success", type:"chain",     message:"LEGyC chain synchronized — node VC-ND-07 canonical",      time:"09:03", read:false },
  { id:"n4", level:"warn",    type:"sms",       message:"SMS batch: 1 notification failed — Jordan (invalid #)",   time:"09:05", read:true  },
  { id:"n5", level:"info",    type:"system",    message:"TotalRecall streaming — last hash 0x92a3...df0c",          time:"09:07", read:true  },
  { id:"n6", level:"info",    type:"tyler",     message:"Tyler Technologies sync complete — docket updated",        time:"08:57", read:true  },
];

const AUDIT_INIT = [
  { id:"a1", ts:"09:12:34", event:"Session Recording Started",    actor:"R. Chen",    case:"CR-24-1087", hash:"0x92a3df0c", segment:"/dalton/session-01/segment-04" },
  { id:"a2", ts:"09:10:11", event:"Biometric Verified: Dalton",   actor:"FacePrint",  case:"CR-24-1087", hash:"0x7f2b1e4a", segment:"/dalton/session-01/bio-01"      },
  { id:"a3", ts:"09:08:55", event:"Remote Participant Joined",    actor:"Att. Johnson",case:"CR-24-1087", hash:"0x4c9d3f8b", segment:"/dalton/session-01/join-01"     },
  { id:"a4", ts:"09:03:22", event:"LEGyC Canonical Sync",         actor:"VC-ND-07",   case:"ALL",        hash:"0x1a5e7c2f", segment:"/chain/sync-0403"               },
  { id:"a5", ts:"08:57:01", event:"CM/ECF Filing Queued",         actor:"Clerk System",case:"CR-24-1087",hash:"0x9b4d6e1c", segment:"/ecf/queue-01"                  },
  { id:"a6", ts:"08:52:44", event:"Biometric Request: Jordan",    actor:"FacePrint",  case:"CR-24-1122", hash:"0x3e8f2a1d", segment:"/jordan/bio-pending-01"         },
];

const TRANSCRIPT_LINES = [
  { speaker:"HON. MARTINEZ", text:"This court is now in session for the arraignment of State v. Dalton, case CR-24-1087." },
  { speaker:"HON. MARTINEZ", text:"Mr. Dalton, you are charged under NC Gen. Stat. § 14-39 — kidnapping. How do you plead?" },
  { speaker:"DEF. DALTON",   text:"Not guilty, Your Honor." },
  { speaker:"ATT. JOHNSON",  text:"Defense requests bail be set at $25,000, Your Honor. My client has no prior record." },
  { speaker:"ATT. RIVERA",   text:"The State objects, Your Honor. Defendant poses a flight risk. We request remand." },
  { speaker:"HON. MARTINEZ", text:"Bail is set at $50,000 with electronic monitoring. Next appearance April 25th." },
];

// ─────────────────────────────────────────────────────────────────────────────
// WEBSOCKET HOOK  (from VideoCourts-WebSocket-Complete/frontend/src/hooks/useWebSocket.js)
// ─────────────────────────────────────────────────────────────────────────────
function useWebSocket(url, { onMessage, onConnect, onDisconnect } = {}) {
  const ws        = useRef(null);
  const [status, setStatus]   = useState("disconnected"); // disconnected | connecting | connected | error
  const reconnectTimer        = useRef(null);
  const mountedRef            = useRef(true);

  const connect = useCallback(() => {
    if (!mountedRef.current) return;
    setStatus("connecting");
    try {
      ws.current = new WebSocket(url);
      ws.current.onopen    = () => { if (!mountedRef.current) return; setStatus("connected");    onConnect?.(); };
      ws.current.onclose   = () => { if (!mountedRef.current) return; setStatus("disconnected"); onDisconnect?.(); scheduleReconnect(); };
      ws.current.onerror   = () => { if (!mountedRef.current) return; setStatus("error"); };
      ws.current.onmessage = (e) => { try { onMessage?.(JSON.parse(e.data)); } catch { onMessage?.(e.data); } };
    } catch { setStatus("error"); scheduleReconnect(); }
  }, [url, onMessage, onConnect, onDisconnect]);

  const scheduleReconnect = useCallback(() => {
    clearTimeout(reconnectTimer.current);
    reconnectTimer.current = setTimeout(connect, 5000);
  }, [connect]);

  const send = useCallback((data) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(typeof data === "string" ? data : JSON.stringify(data));
    }
  }, []);

  const disconnect = useCallback(() => {
    mountedRef.current = false;
    clearTimeout(reconnectTimer.current);
    ws.current?.close();
  }, []);

  // Simulate connected in demo (no real WS server)
  useEffect(() => {
    const t = setTimeout(() => setStatus("connected"), 800);
    return () => { clearTimeout(t); disconnect(); };
  }, []);

  return { status, send, disconnect };
}

// ─────────────────────────────────────────────────────────────────────────────
// TOTALRECALL HOOK  (from constellation25-ecosystem/agents/totalrecall.ts adapted)
// ─────────────────────────────────────────────────────────────────────────────
function useTotalRecall() {
  const [log, setLog]     = useState(AUDIT_INIT);
  const [hash, setHash]   = useState("0x92a3...df0c");
  const [ts, setTs]       = useState("3s ago");

  useEffect(() => {
    const t = setInterval(() => {
      const secs = Math.floor(Math.random() * 10) + 1;
      setTs(`${secs}s ago`);
      setHash("0x" + Math.random().toString(16).slice(2, 10) + "...");
    }, 8000);
    return () => clearInterval(t);
  }, []);

  const append = useCallback((event, actor, caseNum) => {
    const h = "0x" + Math.random().toString(16).slice(2, 10);
    const now = new Date().toLocaleTimeString("en-US", { hour12: false });
    setLog(l => [{ id:`a${Date.now()}`, ts: now, event, actor, case: caseNum, hash: h, segment: `/auto/${Date.now()}` }, ...l]);
    setHash(h);
    setTs("just now");
  }, []);

  return { log, hash, ts, append };
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
const fmtElapsed = (s) => {
  const h  = Math.floor(s / 3600).toString().padStart(2, "0");
  const m  = Math.floor((s % 3600) / 60).toString().padStart(2, "0");
  const se = (s % 60).toString().padStart(2, "0");
  return `${h}:${m}:${se}`;
};

const genHash = () => Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");

const typeIcon = (t) => ({ video:"🎥", document:"📄", image:"🖼️", audio:"🎙️" }[t] ?? "📎");

// ─────────────────────────────────────────────────────────────────────────────
// DESIGN TOKENS — dark judicial aesthetic
// ─────────────────────────────────────────────────────────────────────────────
// Tailwind classes only — no custom CSS needed

// ─────────────────────────────────────────────────────────────────────────────
// UI ATOMS
// ─────────────────────────────────────────────────────────────────────────────
const BADGE_VARIANTS = {
  live:      "bg-red-500/20    text-red-300    border-red-500/40",
  recording: "bg-blue-500/20   text-blue-300   border-blue-500/40",
  remote:    "bg-sky-500/20    text-sky-300    border-sky-500/40",
  scheduled: "bg-indigo-500/20 text-indigo-300 border-indigo-500/40",
  verified:  "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
  pending:   "bg-amber-500/20  text-amber-300  border-amber-500/40",
  mock:      "bg-purple-500/20 text-purple-300 border-purple-500/40",
  jailcourt: "bg-teal-500/20   text-teal-300   border-teal-500/40",
  success:   "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
  warn:      "bg-amber-500/20  text-amber-300  border-amber-500/40",
  info:      "bg-cyan-500/20   text-cyan-300   border-cyan-500/40",
  error:     "bg-red-500/20    text-red-300    border-red-500/40",
  closed:    "bg-slate-700/30  text-slate-500  border-slate-700/40",
  default:   "bg-slate-700/50  text-slate-300  border-slate-600/40",
  ws_connected:    "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
  ws_connecting:   "bg-amber-500/20   text-amber-300   border-amber-500/40",
  ws_disconnected: "bg-slate-700/50   text-slate-500   border-slate-600/40",
  ws_error:        "bg-red-500/20     text-red-300     border-red-500/40",
};

const Badge = ({ variant = "default", pulse, children, className = "" }) => (
  <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${BADGE_VARIANTS[variant] ?? BADGE_VARIANTS.default} ${className}`}>
    {pulse && <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />}
    {children}
  </span>
);

const BTN_VARIANTS = {
  primary:   "bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-white shadow-lg shadow-cyan-900/30",
  secondary: "bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200",
  danger:    "bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-red-300",
  success:   "bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300",
  ghost:     "bg-transparent hover:bg-slate-800 text-slate-400 hover:text-slate-200",
  warn:      "bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-300",
};
const BTN_SIZES = { xs:"px-2.5 py-1 text-xs", sm:"px-3.5 py-1.5 text-xs", md:"px-5 py-2.5 text-sm", lg:"px-7 py-3 text-base" };

const Btn = ({ variant="primary", size="md", onClick, children, className="", disabled }) => (
  <button
    disabled={disabled}
    onClick={onClick}
    className={`inline-flex items-center justify-center gap-2 font-semibold rounded-lg transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed ${BTN_SIZES[size]} ${BTN_VARIANTS[variant]} ${className}`}
  >
    {children}
  </button>
);

const Input = ({ label, ...props }) => (
  <div>
    {label && <label className="block text-xs text-slate-500 mb-1.5 font-medium">{label}</label>}
    <input className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-white text-sm placeholder-slate-600 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/30 transition-colors" {...props} />
  </div>
);

const SelectInput = ({ label, options, ...props }) => (
  <div>
    {label && <label className="block text-xs text-slate-500 mb-1.5 font-medium">{label}</label>}
    <select className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-white text-sm focus:border-cyan-500 focus:outline-none transition-colors" {...props}>
      {options.map(o => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}
    </select>
  </div>
);

const TextArea = ({ label, ...props }) => (
  <div>
    {label && <label className="block text-xs text-slate-500 mb-1.5 font-medium">{label}</label>}
    <textarea className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-white text-sm placeholder-slate-600 focus:border-cyan-500 focus:outline-none resize-none transition-colors" rows={3} {...props} />
  </div>
);

const Card = ({ children, className = "", onClick, highlight }) => (
  <div
    onClick={onClick}
    className={`bg-slate-800/70 border rounded-xl p-5 transition-all
      ${highlight ? "border-cyan-500/60 shadow-lg shadow-cyan-900/20" : "border-slate-700/60"}
      ${onClick ? "cursor-pointer hover:border-cyan-500/50 hover:shadow-lg hover:shadow-cyan-900/20" : ""}
      ${className}`}
  >
    {children}
  </div>
);

const StatCard = ({ label, value, color="text-cyan-400", icon, sub }) => (
  <Card>
    <div className="flex items-start justify-between">
      <div>
        <div className={`text-3xl font-extrabold mb-0.5 tabular-nums ${color}`}>{value}</div>
        <div className="text-sm text-slate-400">{label}</div>
        {sub && <div className="text-xs text-slate-600 mt-1">{sub}</div>}
      </div>
      {icon && <span className="text-2xl opacity-40">{icon}</span>}
    </div>
  </Card>
);

const SectionHead = ({ title, subtitle, action }) => (
  <div className="flex items-start justify-between mb-6">
    <div>
      <h2 className="text-xl font-extrabold text-white tracking-tight">{title}</h2>
      {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
    </div>
    {action}
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// MODAL SHELL
// ─────────────────────────────────────────────────────────────────────────────
const Modal = ({ title, onClose, children, wide, fullscreen }) => (
  <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
    <div
      onClick={e => e.stopPropagation()}
      className={`bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] w-full
        ${fullscreen ? "max-w-6xl" : wide ? "max-w-4xl" : "max-w-xl"}`}
    >
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 shrink-0">
        <h3 className="text-lg font-bold">{title}</h3>
        <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors text-xl w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-800">✕</button>
      </div>
      <div className="overflow-y-auto flex-1 px-6 py-5">{children}</div>
    </div>
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// VIDEO ROOM  (SimpleWebRTC / Jitsi / Daily.co — from VideoCourts-Video/)
// ─────────────────────────────────────────────────────────────────────────────
const VideoRoom = ({ session, provider = "SimpleWebRTC", onClose }) => {
  const [connected, setConnected]   = useState(false);
  const [muted, setMuted]           = useState(false);
  const [camOff, setCamOff]         = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const videoRef = useRef(null);

  useEffect(() => {
    // Simulate connection — in prod this boots Jitsi / Daily / SimpleWebRTC SDK
    const t = setTimeout(() => setConnected(true), 1500);
    return () => clearTimeout(t);
  }, []);

  const providerNote = {
    "SimpleWebRTC": "WebRTC peer-to-peer — no third-party server. All traffic stays within C25 infrastructure.",
    "Jitsi":        "Jitsi Meet — open-source HIPAA-eligible conferencing. Hosted on videocourts.com/jitsi.",
    "Daily.co":     "Daily.co SDK — enterprise WebRTC with recording, transcription, and compliance APIs.",
  }[provider];

  return (
    <Modal title={`🎥 Courtroom ${session.courtroom} — ${session.title}`} onClose={onClose} fullscreen>
      {/* Video Grid */}
      <div className={`grid gap-3 mb-4 ${connected ? "grid-cols-3" : "grid-cols-1"}`}>
        {/* Main — Judge */}
        <div className={`relative bg-slate-950 rounded-xl overflow-hidden ${connected ? "col-span-2" : ""}`} style={{ aspectRatio: "16/9" }}>
          {!connected ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mb-3" />
              <p className="text-slate-400 text-sm">Connecting via {provider}…</p>
            </div>
          ) : (
            <>
              <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-black flex items-center justify-center">
                <div className="text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-700 to-slate-600 flex items-center justify-center text-3xl font-bold mb-3 mx-auto">H</div>
                  <p className="text-slate-300 font-semibold">{session.judge}</p>
                  <p className="text-xs text-slate-500">Presiding Judge · Courtroom {session.courtroom}</p>
                </div>
              </div>
              {/* Live indicator */}
              <div className="absolute top-3 left-3 flex items-center gap-2 bg-red-600/90 px-3 py-1 rounded-full text-xs font-bold">
                <span className="w-2 h-2 rounded-full bg-white animate-pulse" /> LIVE
              </div>
              {/* Chain indicator */}
              <div className="absolute bottom-3 left-3 text-xs font-mono text-green-400 bg-black/60 px-2 py-1 rounded">
                ⛓ LEGyC: {session.caseNumber}/session-01
              </div>
            </>
          )}
        </div>

        {/* Side tiles — participants */}
        {connected && (
          <div className="flex flex-col gap-3">
            {session.participants.slice(0, 3).map((p, i) => (
              <div key={i} className="bg-slate-950 rounded-xl flex items-center justify-center relative overflow-hidden" style={{ aspectRatio: "16/9" }}>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center font-bold text-sm">{p[0]}</div>
                <div className="absolute bottom-1 left-2 text-xs text-slate-400">{p.split(" ").slice(-1)[0]}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex gap-3 mb-4">
        <Btn variant={muted ? "danger" : "secondary"} onClick={() => setMuted(m => !m)} className="flex-1">
          {muted ? "🔇 Unmute" : "🎙 Mute"}
        </Btn>
        <Btn variant={camOff ? "danger" : "secondary"} onClick={() => setCamOff(c => !c)} className="flex-1">
          {camOff ? "📷 Camera Off" : "📹 Camera On"}
        </Btn>
        <Btn variant="secondary" onClick={() => alert("Screen sharing not available in standalone mode — use Jitsi or Daily provider.")} className="flex-1">
          🖥 Share Screen
        </Btn>
        <Btn variant="danger" onClick={onClose}>Leave</Btn>
      </div>

      {/* Provider info */}
      <div className="bg-slate-800/50 rounded-xl p-3 flex gap-3 items-start">
        <span className="text-lg">ℹ️</span>
        <div>
          <p className="text-xs font-semibold text-slate-300 mb-0.5">Provider: {provider}</p>
          <p className="text-xs text-slate-500">{providerNote}</p>
        </div>
      </div>
    </Modal>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// LIVE SESSION PANEL  (from HearingRoom.tsx + VideoCourt.js merged)
// ─────────────────────────────────────────────────────────────────────────────
const LiveSessionPanel = ({ session, elapsed, recording, setRecording, videoProvider, setVideoProvider, tr, onClose }) => {
  const [tab, setTab]               = useState("overview");
  const [showVideo, setShowVideo]   = useState(false);
  const [chatMsg, setChatMsg]       = useState("");
  const [chatLog, setChatLog]       = useState([
    { from:"R. Chen",     text:"Session initialized. Recording active.", ts:"09:00" },
    { from:"Att. Johnson",text:"Counsel for defense appearing remotely.", ts:"09:01" },
  ]);

  const sendChat = () => {
    if (!chatMsg.trim()) return;
    setChatLog(l => [...l, { from:"You (Clerk)", text: chatMsg, ts: new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"}) }]);
    setChatMsg("");
  };

  const tabs = ["overview","transcript","participants","evidence","chat"];

  return (
    <>
      <Modal title={`${session.status === "live" ? "🔴 LIVE —" : ""} ${session.title}`} onClose={onClose} fullscreen>
        {/* Header strip */}
        <div className="grid grid-cols-2 gap-4 mb-4 bg-slate-800/50 rounded-xl p-4">
          <div className="space-y-1 text-sm">
            <p><span className="text-slate-500">Case:</span> <span className="text-cyan-400 font-mono">{session.caseNumber}</span></p>
            <p><span className="text-slate-500">Court:</span> {session.circuit} · Courtroom {session.courtroom}</p>
            <p><span className="text-slate-500">Judge:</span> {session.judge} &nbsp;·&nbsp; <span className="text-slate-500">Clerk:</span> {session.clerk}</p>
            <p><span className="text-slate-500">Type:</span> {session.type} &nbsp;·&nbsp; <span className="text-slate-500">Mode:</span> {session.mode}</p>
          </div>
          <div className="text-right space-y-1">
            {session.status === "live" && (
              <p className="text-green-400 font-mono text-2xl font-bold">{fmtElapsed(elapsed)}</p>
            )}
            <div className="flex gap-2 justify-end flex-wrap">
              {session.status === "live"      && <Badge variant="live" pulse>LIVE</Badge>}
              {recording                       && <Badge variant="recording" pulse>🎥 REC</Badge>}
              {session.legyc                   && <Badge variant="verified">⛓ Chain</Badge>}
              {session.biometric === "Verified"&& <Badge variant="verified">🔐 Bio OK</Badge>}
              {session.biometric === "Pending" && <Badge variant="pending">🔐 Bio Pending</Badge>}
            </div>
            {session.nextMatter && (
              <p className="text-xs text-slate-500">Next: <span className="text-slate-300">{session.nextMatter}</span></p>
            )}
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex gap-1 mb-4 bg-slate-800/50 p-1 rounded-xl">
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg capitalize transition-colors
                ${tab === t ? "bg-slate-700 text-white" : "text-slate-500 hover:text-slate-300"}`}>
              {t}
            </button>
          ))}
        </div>

        {/* ── Overview tab ── */}
        {tab === "overview" && (
          <div className="space-y-4">
            {/* Video stream placeholder */}
            <div className="bg-slate-950 rounded-xl overflow-hidden relative" style={{ aspectRatio:"16/9" }}>
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950">
                <span className="text-6xl opacity-20 mb-3">🎥</span>
                <p className="text-slate-400 text-sm font-medium">Courtroom {session.courtroom} — Live Stream</p>
                <p className="text-slate-600 text-xs mt-1">Bench, parties and observers appear here on connection</p>
                <Btn className="mt-4" onClick={() => setShowVideo(true)}>▶ Join Courtroom Video</Btn>
              </div>
              {recording && (
                <div className="absolute top-3 right-3 flex items-center gap-2 bg-red-600/90 px-3 py-1 rounded-full text-xs font-bold">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" /> REC
                </div>
              )}
              {session.legyc && (
                <div className="absolute bottom-3 left-3 text-xs font-mono text-green-400 bg-black/60 px-2 py-1 rounded">
                  LEGyC: {session.caseNumber}/session-01/segment-04 · Notarized
                </div>
              )}
            </div>

            {/* Action bar */}
            <div className="flex gap-3 flex-wrap">
              <Btn variant="primary" onClick={() => setShowVideo(true)}>▶ Join Courtroom</Btn>
              <Btn variant={recording ? "danger" : "success"} onClick={() => { setRecording(r => !r); tr.append(recording ? "Recording Paused" : "Recording Started", "Clerk", session.caseNumber); }}>
                {recording ? "⏸ Pause Rec" : "⏺ Start Rec"}
              </Btn>
              <Btn variant="secondary" onClick={() => { tr.append("Audit Trail Opened", "Clerk", session.caseNumber); alert("Audit trail opened in TotalRecall tab."); }}>📋 Audit Trail</Btn>
              <Btn variant="warn" onClick={() => alert("Biometric check initiated via FacePrintPay…")}>🔐 Verify Bio</Btn>
            </div>

            {/* Video provider selector */}
            <div className="bg-slate-800/50 rounded-xl p-4">
              <p className="text-xs font-semibold text-slate-400 mb-2">Video Provider</p>
              <div className="flex gap-2">
                {VIDEO_PROVIDERS.map(p => (
                  <button key={p} onClick={() => setVideoProvider(p)}
                    className={`px-3 py-1.5 text-xs rounded-lg font-semibold transition-colors border
                      ${videoProvider === p ? "border-cyan-500 bg-cyan-900/20 text-cyan-400" : "border-slate-700 text-slate-500 hover:border-slate-600"}`}>
                    {p}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-600 mt-2">
                {videoProvider === "SimpleWebRTC" && "Peer-to-peer · No third-party server"}
                {videoProvider === "Jitsi"        && "Open-source HIPAA-eligible · Self-hosted"}
                {videoProvider === "Daily.co"     && "Enterprise WebRTC · Recording + transcription"}
              </p>
            </div>
          </div>
        )}

        {/* ── Transcript tab ── */}
        {tab === "transcript" && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="warn" pulse>Draft Live</Badge>
              <span className="text-xs text-slate-500">AI-assisted transcription — verify against recording before filing</span>
            </div>
            {TRANSCRIPT_LINES.map((l, i) => (
              <div key={i} className="bg-slate-800/50 rounded-xl p-3 border border-slate-700/40">
                <p className="text-xs font-bold text-cyan-400 mb-1">{l.speaker}</p>
                <p className="text-sm text-slate-300 font-mono">{l.text}</p>
              </div>
            ))}
            <div className="flex gap-3 pt-2">
              <Btn size="sm" variant="secondary" onClick={() => alert("Downloading transcript draft…")}>⬇ Download Draft</Btn>
              <Btn size="sm" variant="secondary" onClick={() => alert("Submitting to CM/ECF…")}>📎 Submit to CM/ECF</Btn>
            </div>
          </div>
        )}

        {/* ── Participants tab ── */}
        {tab === "participants" && (
          <div className="space-y-2">
            {session.participants.map((p, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-800/50 rounded-xl px-4 py-3 border border-slate-700/40">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan-700 to-slate-600 flex items-center justify-center text-sm font-bold">{p[0]}</div>
                  <div>
                    <p className="text-sm font-semibold text-slate-200">{p}</p>
                    <p className="text-xs text-slate-500">{i === 0 ? "Presiding Judge" : i === 1 ? "Clerk of Court" : i <= 2 ? "Defendant" : "Counsel"}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Badge variant="verified">✓ Verified</Badge>
                  <Badge variant="live" pulse>Online</Badge>
                </div>
              </div>
            ))}
            <Btn size="sm" variant="secondary" className="mt-2" onClick={() => alert("Add participant flow…")}>+ Add Participant</Btn>
          </div>
        )}

        {/* ── Evidence tab ── */}
        {tab === "evidence" && (
          <div>
            <p className="text-sm text-slate-400 mb-3">Evidence admitted in {session.caseNumber}</p>
            {EVIDENCE_INIT.filter(e => e.caseNumber === session.caseNumber).map(e => (
              <div key={e.id} className="flex items-center gap-3 bg-slate-800/50 rounded-xl px-4 py-3 border border-slate-700/40 mb-2">
                <span className="text-2xl">{typeIcon(e.type)}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-200 truncate">{e.fileName}</p>
                  <p className="text-xs font-mono text-cyan-400 mt-0.5 truncate">{e.hash.slice(0,28)}…</p>
                </div>
                <Badge variant={e.status === "verified" ? "verified" : "pending"}>{e.status === "verified" ? "✓" : "⏳"}</Badge>
              </div>
            ))}
            {EVIDENCE_INIT.filter(e => e.caseNumber === session.caseNumber).length === 0 && (
              <p className="text-slate-600 text-sm">No evidence linked to this session yet.</p>
            )}
          </div>
        )}

        {/* ── Chat tab ── */}
        {tab === "chat" && (
          <div className="flex flex-col h-72">
            <div className="flex-1 overflow-y-auto space-y-2 mb-3">
              {chatLog.map((m, i) => (
                <div key={i} className={`flex gap-2 ${m.from.startsWith("You") ? "flex-row-reverse" : ""}`}>
                  <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold shrink-0">{m.from[0]}</div>
                  <div className={`max-w-xs px-3 py-2 rounded-xl text-sm ${m.from.startsWith("You") ? "bg-cyan-900/40 text-cyan-100" : "bg-slate-800 text-slate-200"}`}>
                    <p className="text-xs text-slate-500 mb-0.5">{m.from} · {m.ts}</p>
                    {m.text}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
                placeholder="Message court participants…"
                value={chatMsg}
                onChange={e => setChatMsg(e.target.value)}
                onKeyDown={e => e.key === "Enter" && sendChat()}
              />
              <Btn onClick={sendChat}>Send</Btn>
            </div>
          </div>
        )}
      </Modal>

      {showVideo && (
        <VideoRoom session={session} provider={videoProvider} onClose={() => setShowVideo(false)} />
      )}
    </>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// SESSION CARD
// ─────────────────────────────────────────────────────────────────────────────
const SessionCard = ({ session, elapsed, onClick }) => (
  <Card onClick={onClick} highlight={session.status === "live"}>
    <div className="flex justify-between items-start mb-3">
      <div className="flex-1 min-w-0">
        <div className="flex gap-2 flex-wrap mb-2">
          {session.status === "live"      && <Badge variant="live" pulse>🔴 LIVE</Badge>}
          {session.status === "scheduled" && <Badge variant="scheduled">⏰ Scheduled</Badge>}
          {session.status === "mock"      && <Badge variant="mock">🎭 Mock</Badge>}
          {session.recording              && <Badge variant="recording" pulse>🎥 REC</Badge>}
          {session.remote && !session.jailcourt && !session.mock && <Badge variant="remote">🌐 Remote</Badge>}
          {session.jailcourt              && <Badge variant="jailcourt">🏛 JailCourt</Badge>}
        </div>
        <h4 className="font-bold text-white truncate">{session.title}</h4>
        <p className="text-xs text-slate-500 mt-0.5">{session.caseNumber} · {session.circuit}</p>
      </div>
      <div className="text-right ml-3 shrink-0">
        <p className="text-xs text-slate-500">{session.time} · {session.type}</p>
        {session.status === "live" && (
          <p className="text-xs text-green-400 font-mono mt-1">⏱ {fmtElapsed(elapsed)}</p>
        )}
      </div>
    </div>
    <div className="flex gap-4 pt-3 border-t border-slate-700/40">
      <div><p className="text-xs text-slate-600">Judge</p><p className="text-sm text-slate-300">{session.judge}</p></div>
      {session.clerk && session.clerk !== "—" && <div><p className="text-xs text-slate-600">Clerk</p><p className="text-sm text-slate-300">{session.clerk}</p></div>}
      <div className="ml-auto"><p className="text-xs text-slate-600">Mode</p><p className="text-sm text-slate-300">{session.mode}</p></div>
    </div>
  </Card>
);

// ─────────────────────────────────────────────────────────────────────────────
// MODALS — CRUD
// ─────────────────────────────────────────────────────────────────────────────
const ScheduleModal = ({ onClose, onSave }) => {
  const [f, setF] = useState({ title:"", caseNumber:"", type:"Arraignment", date:"", time:"", judge:"Hon. Martinez", mode:"Live", courtroom:"4B", notes:"" });
  const u = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <Modal title="📅 Schedule New Hearing" onClose={onClose}>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Input label="Case Title" placeholder="State v. …" value={f.title} onChange={e => u("title", e.target.value)} />
          <Input label="Case Number" placeholder="CR-24-XXXX" value={f.caseNumber} onChange={e => u("caseNumber", e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <SelectInput label="Hearing Type" value={f.type} onChange={e => u("type", e.target.value)}
            options={["Arraignment","Bond Review","Motion Hearing","Plea Hearing","Status Conference","Trial","Civil Motion","Sentencing","Contempt","Emergency"]} />
          <SelectInput label="Mode" value={f.mode} onChange={e => u("mode", e.target.value)} options={["Live","Remote","JailCourt","Mock","Hybrid"]} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input label="Date" type="date" value={f.date} onChange={e => u("date", e.target.value)} />
          <Input label="Time" type="time" value={f.time} onChange={e => u("time", e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <SelectInput label="Judge" value={f.judge} onChange={e => u("judge", e.target.value)}
            options={["Hon. Martinez","Hon. Chen","Hon. Johnson","Hon. Williams","Hon. Thompson"]} />
          <Input label="Courtroom" placeholder="4B" value={f.courtroom} onChange={e => u("courtroom", e.target.value)} />
        </div>
        <TextArea label="Notes" placeholder="Hearing notes, special instructions…" value={f.notes} onChange={e => u("notes", e.target.value)} />
        <div className="flex gap-3 pt-2">
          <Btn className="flex-1" onClick={() => { onSave(f); onClose(); }} disabled={!f.title || !f.caseNumber}>Create Hearing</Btn>
          <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
        </div>
      </div>
    </Modal>
  );
};

const NewCaseModal = ({ onClose, onSave }) => {
  const [f, setF] = useState({ title:"", caseNumber:"", type:"Criminal", judge:"Hon. Martinez", circuit:"3rd Judicial Circuit", attorneys:"" });
  const u = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <Modal title="📁 Create New Case" onClose={onClose}>
      <div className="space-y-4">
        <Input label="Case Title" placeholder="Plaintiff v. Defendant" value={f.title} onChange={e => u("title", e.target.value)} />
        <Input label="Case Number" placeholder="CR-24-XXXX" value={f.caseNumber} onChange={e => u("caseNumber", e.target.value)} />
        <div className="grid grid-cols-2 gap-3">
          <SelectInput label="Case Type" value={f.type} onChange={e => u("type", e.target.value)} options={["Criminal","Civil","Family","Probate","Juvenile","Traffic","Appellate"]} />
          <SelectInput label="Circuit" value={f.circuit} onChange={e => u("circuit", e.target.value)} options={["3rd Judicial Circuit","Municipal Court","Family Court","Superior Court","District Court"]} />
        </div>
        <SelectInput label="Assigned Judge" value={f.judge} onChange={e => u("judge", e.target.value)}
          options={["Hon. Martinez","Hon. Chen","Hon. Johnson","Hon. Williams","Hon. Thompson"]} />
        <Input label="Attorneys (comma separated)" placeholder="Att. Smith, Att. Jones" value={f.attorneys} onChange={e => u("attorneys", e.target.value)} />
        <div className="flex gap-3 pt-2">
          <Btn className="flex-1" onClick={() => { onSave(f); onClose(); }} disabled={!f.title || !f.caseNumber}>Create Case</Btn>
          <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
        </div>
      </div>
    </Modal>
  );
};

const UploadModal = ({ cases, onClose, onSave }) => {
  const [f, setF] = useState({ caseId:"c1", fileName:"", uploadedBy:"", type:"document", notes:"" });
  const u = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <Modal title="🔐 Upload Evidence" onClose={onClose}>
      <div className="space-y-4">
        <SelectInput label="Case" value={f.caseId} onChange={e => u("caseId", e.target.value)}
          options={cases.map(c => ({ value: c.id, label: `${c.caseNumber} — ${c.title}` }))} />
        <Input label="File Name" placeholder="evidence_001.mp4" value={f.fileName} onChange={e => u("fileName", e.target.value)} />
        <div className="grid grid-cols-2 gap-3">
          <SelectInput label="Evidence Type" value={f.type} onChange={e => u("type", e.target.value)} options={["document","video","image","audio","other"]} />
          <Input label="Submitted By" placeholder="Officer / Attorney name" value={f.uploadedBy} onChange={e => u("uploadedBy", e.target.value)} />
        </div>
        <div className="border-2 border-dashed border-slate-700 rounded-xl p-8 text-center hover:border-cyan-600/50 transition-colors cursor-pointer">
          <div className="text-5xl mb-2 opacity-40">📎</div>
          <p className="text-sm text-slate-400">Drag & drop file or click to select</p>
          <p className="text-xs text-slate-600 mt-1">SHA-256 hash generated automatically on upload</p>
          <p className="text-xs text-slate-600">Chain-of-custody logged to TotalRecall / LEGyC</p>
        </div>
        <TextArea label="Notes" placeholder="Chain-of-custody notes, provenance…" value={f.notes} onChange={e => u("notes", e.target.value)} />
        <div className="flex gap-3 pt-2">
          <Btn className="flex-1" onClick={() => { onSave(f); onClose(); }} disabled={!f.fileName || !f.uploadedBy}>Upload & Hash</Btn>
          <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
        </div>
      </div>
    </Modal>
  );
};

const CaseDetailModal = ({ c, onClose, onSchedule }) => (
  <Modal title={c.title} onClose={onClose} wide>
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3 text-sm">
        {[
          ["Case Number", <span className="text-cyan-400 font-mono">{c.caseNumber}</span>],
          ["Type",         c.type],
          ["Status",       <Badge variant={c.status === "active" ? "verified" : "closed"}>{c.status}</Badge>],
          ["Filed",        c.filed],
          ["Judge",        c.judge],
          ["Circuit",      c.circuit],
          ["Docket Items", c.docket],
          ["Attorneys",    c.attorneys?.join(", ") ?? "—"],
        ].map(([label, val]) => (
          <div key={label} className="bg-slate-800/50 rounded-lg p-3">
            <p className="text-xs text-slate-500 mb-1">{label}</p>
            <div className="text-slate-200">{val}</div>
          </div>
        ))}
      </div>

      {/* Docket timeline (mock) */}
      <div>
        <p className="text-xs font-semibold text-slate-500 mb-2 uppercase tracking-wider">Recent Docket Activity</p>
        <div className="space-y-2">
          {[
            { date:"2025-02-15", event:"Evidence submitted by Att. Johnson" },
            { date:"2025-02-10", event:"Arraignment scheduled — CR-24-1087" },
            { date:"2025-01-20", event:"Initial appearance — defendant appeared" },
            { date:"2025-01-15", event:"Case filed and docketed" },
          ].map((d, i) => (
            <div key={i} className="flex gap-3 items-start">
              <div className="w-2 h-2 rounded-full bg-cyan-500 mt-1.5 shrink-0" />
              <div>
                <p className="text-xs text-slate-500">{d.date}</p>
                <p className="text-sm text-slate-300">{d.event}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        <Btn onClick={() => { onSchedule?.(); onClose(); }}>📅 Schedule Hearing</Btn>
        <Btn variant="secondary" onClick={() => alert("Opening CM/ECF filing…")}>📎 CM/ECF Filing</Btn>
        <Btn variant="secondary" onClick={() => alert("Opening evidence vault…")}>🔐 Evidence</Btn>
        <Btn variant="secondary" onClick={() => alert("Generating docket report…")}>📋 Full Docket</Btn>
      </div>
    </div>
  </Modal>
);

// ─────────────────────────────────────────────────────────────────────────────
// VIEWS
// ─────────────────────────────────────────────────────────────────────────────
const DashboardView = ({ sessions, cases, elapsed, onOpenSession, onSchedule }) => {
  const [modeFilter,    setModeFilter]    = useState("All");
  const [circuitFilter, setCircuitFilter] = useState("all");

  const filtered = sessions.filter(s =>
    (circuitFilter === "all" || s.circuit === circuitFilter) &&
    (modeFilter    === "All"
      || (modeFilter === "Live"      && s.status === "live")
      || (modeFilter === "Remote"    && s.remote && !s.jailcourt)
      || (modeFilter === "JailCourt" && s.jailcourt)
      || (modeFilter === "Mock"      && s.mock))
  );

  return (
    <div>
      <SectionHead title="Court Day Overview" subtitle="Bench: 3rd Judicial Circuit · Morning Docket"
        action={<Btn onClick={onSchedule}>+ Schedule Hearing</Btn>} />

      <div className="grid grid-cols-4 gap-4 mb-6">
        <StatCard label="Today's Hearings" value={sessions.length}                                     color="text-cyan-400"    icon="📅" />
        <StatCard label="Live Now"         value={sessions.filter(s => s.status === "live").length}    color="text-green-400"   icon="🔴" />
        <StatCard label="Scheduled"        value={sessions.filter(s => s.status === "scheduled").length} color="text-blue-400" icon="⏰" />
        <StatCard label="Active Cases"     value={cases.filter(c => c.status === "active").length}    color="text-amber-400"   icon="📁" />
      </div>

      <div className="flex gap-3 mb-5 flex-wrap">
        <select className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200"
          value={circuitFilter} onChange={e => setCircuitFilter(e.target.value)}>
          <option value="all">All Circuits</option>
          <option value="3rd Judicial Circuit">3rd Judicial Circuit</option>
          <option value="Family Court">Family Court</option>
          <option value="Mock Trial Lab">Mock Trial Lab</option>
        </select>
        <div className="flex gap-1 bg-slate-800 border border-slate-700 rounded-lg p-1">
          {["All","Live","Remote","JailCourt","Mock"].map(m => (
            <button key={m} onClick={() => setModeFilter(m)}
              className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors
                ${modeFilter === m ? "bg-slate-600 text-white" : "text-slate-500 hover:text-slate-300"}`}>{m}</button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {filtered.map(s => <SessionCard key={s.id} session={s} elapsed={elapsed} onClick={() => onOpenSession(s)} />)}
        {filtered.length === 0 && <p className="text-center py-10 text-slate-600">No sessions match current filters.</p>}
      </div>
    </div>
  );
};

const CasesView = ({ cases, onNewCase, onViewCase }) => {
  const [search, setSearch]     = useState("");
  const [typeFilter, setType]   = useState("All");
  const [statusFilter, setStatus] = useState("All");

  const filtered = cases.filter(c =>
    (c.title.toLowerCase().includes(search.toLowerCase()) || c.caseNumber.toLowerCase().includes(search.toLowerCase())) &&
    (typeFilter   === "All" || c.type   === typeFilter) &&
    (statusFilter === "All" || c.status === statusFilter)
  );

  return (
    <div>
      <SectionHead title="Cases & Dockets" subtitle="Search, view, and manage court cases"
        action={<Btn onClick={onNewCase}>+ New Case</Btn>} />
      <div className="flex gap-3 mb-5 flex-wrap">
        <input className="flex-1 min-w-48 bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-sm text-white placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
          placeholder="Search case number or title…" value={search} onChange={e => setSearch(e.target.value)} />
        <select className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200" value={typeFilter} onChange={e => setType(e.target.value)}>
          {["All","Criminal","Civil","Family","Probate"].map(t => <option key={t}>{t}</option>)}
        </select>
        <select className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200" value={statusFilter} onChange={e => setStatus(e.target.value)}>
          {["All","active","closed"].map(t => <option key={t}>{t}</option>)}
        </select>
      </div>
      <div className="space-y-3">
        {filtered.map(c => (
          <Card key={c.id} onClick={() => onViewCase(c)}>
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-bold text-white">{c.title}</h4>
                <p className="text-xs text-slate-500 mt-0.5">{c.caseNumber} · {c.type} · Filed {c.filed}</p>
                <p className="text-xs text-slate-500">{c.judge} · {c.circuit}</p>
              </div>
              <div className="flex flex-col items-end gap-2 ml-4">
                <Badge variant={c.status === "active" ? "verified" : "closed"}>{c.status}</Badge>
                <span className="text-xs text-slate-600">{c.docket} docket entries</span>
              </div>
            </div>
            <div className="flex gap-2 mt-4" onClick={e => e.stopPropagation()}>
              <Btn size="sm" onClick={() => onViewCase(c)}>View Details</Btn>
              <Btn size="sm" variant="secondary">Schedule Hearing</Btn>
              <Btn size="sm" variant="secondary">CM/ECF</Btn>
            </div>
          </Card>
        ))}
        {filtered.length === 0 && <p className="text-center py-10 text-slate-600">No cases match search criteria.</p>}
      </div>
    </div>
  );
};

const HearingsView = ({ sessions, elapsed, onOpenSession, onSchedule }) => (
  <div>
    <SectionHead title="Hearings & Calendar" subtitle="All scheduled and active court hearings"
      action={<Btn onClick={onSchedule}>+ Schedule Hearing</Btn>} />
    <div className="grid grid-cols-3 gap-4 mb-6">
      {[["Today",    sessions.length],["Tomorrow", 2],["This Week", 9]].map(([label, val], i) => (
        <Card key={i} highlight={i === 0}>
          <p className="text-xs text-slate-500 mb-1">{label}</p>
          <p className="text-3xl font-extrabold text-white">{val}</p>
          <p className="text-xs text-slate-600">hearings</p>
        </Card>
      ))}
    </div>
    <div className="space-y-3">
      {sessions.map(s => <SessionCard key={s.id} session={s} elapsed={elapsed} onClick={() => onOpenSession(s)} />)}
    </div>
  </div>
);

const JailCourtView = ({ sessions, elapsed, onOpenSession, tr }) => {
  const jailSessions = sessions.filter(s => s.jailcourt);
  return (
    <div>
      <SectionHead title="JailCourt Management" subtitle="Remote appearances from correctional facilities" />
      <div className="bg-teal-500/10 border border-teal-500/20 rounded-xl p-5 mb-6">
        <div className="flex items-center gap-3 mb-3">
          <span className="text-3xl">🏛</span>
          <div>
            <h3 className="font-bold text-teal-300 text-lg">JailCourt Active</h3>
            <p className="text-xs text-slate-400">All appearances require FacePrint biometric verification. Sessions encrypted and LEGyC chain-logged.</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[["Scheduled", jailSessions.length,"text-teal-300"],["Bio Pending",1,"text-amber-300"],["Active Now",0,"text-green-300"]].map(([l,v,c]) => (
            <div key={l} className="bg-slate-800/50 rounded-lg p-3 text-center">
              <p className={`text-2xl font-bold ${c}`}>{v}</p>
              <p className="text-xs text-slate-500">{l}</p>
            </div>
          ))}
        </div>
      </div>

      {jailSessions.map(s => <SessionCard key={s.id} session={s} elapsed={elapsed} onClick={() => onOpenSession(s)} />)}

      {/* Biometric queue */}
      <div className="mt-6">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Biometric Verification Queue</p>
        <Card>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🔐</span>
              <div>
                <p className="font-semibold">Jordan — CR-24-1122</p>
                <p className="text-xs text-slate-500">JailCourt · 09:45 · County Detention Center · Pod B</p>
              </div>
            </div>
            <div className="flex gap-2 flex-col items-end">
              <Badge variant="pending" pulse>Pending</Badge>
              <Btn size="sm" onClick={() => { tr.append("Biometric Initiated: Jordan","FacePrint","CR-24-1122"); alert("FacePrintPay biometric verification initiated for Jordan…"); }}>🔐 Verify Now</Btn>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

const EvidenceView = ({ evidence, cases, onUpload, tr }) => {
  const [caseFilter, setCaseFilter] = useState("all");
  const [detail, setDetail]         = useState(null);

  const filtered = evidence.filter(e => caseFilter === "all" || e.caseId === caseFilter);

  return (
    <div>
      <SectionHead title="Evidence Vault" subtitle="Forensic evidence with blockchain chain-of-custody"
        action={<Btn onClick={onUpload}>+ Upload Evidence</Btn>} />

      <div className="flex gap-3 mb-5 flex-wrap items-center">
        <select className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200"
          value={caseFilter} onChange={e => setCaseFilter(e.target.value)}>
          <option value="all">All Cases</option>
          {cases.map(c => <option key={c.id} value={c.id}>{c.caseNumber}</option>)}
        </select>
        <Badge variant="verified">⛓ Chain Verified · Node {NODE_ID}</Badge>
      </div>

      <div className="space-y-3">
        {filtered.map(e => (
          <Card key={e.id} onClick={() => setDetail(e)}>
            <div className="flex items-start gap-4">
              <span className="text-4xl mt-1">{typeIcon(e.type)}</span>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-semibold text-white">{e.fileName}</h4>
                    <p className="text-xs text-slate-500">{e.uploadedBy} · {e.uploadDate} · {e.size} · {e.caseNumber}</p>
                  </div>
                  <Badge variant={e.status === "verified" ? "verified" : "pending"}>
                    {e.status === "verified" ? "✓ Verified" : "⏳ Pending"}
                  </Badge>
                </div>
                <div className="bg-slate-900 rounded-lg p-2.5 mb-3">
                  <p className="text-xs text-slate-600 mb-1">SHA-256</p>
                  <p className="text-xs font-mono text-cyan-400 break-all">{e.hash}</p>
                </div>
                <div className="flex gap-2" onClick={ev => ev.stopPropagation()}>
                  <Btn size="sm" onClick={() => alert(`Downloading ${e.fileName}…`)}>⬇ Download</Btn>
                  <Btn size="sm" variant="secondary" onClick={() => { tr.append("Chain Verified: " + e.fileName,"Clerk",e.caseNumber); alert("Chain verified — confirmed immutable."); }}>⛓ Verify</Btn>
                  <Btn size="sm" variant="secondary" onClick={() => setDetail(e)}>Details</Btn>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {detail && (
        <Modal title={`Evidence: ${detail.fileName}`} onClose={() => setDetail(null)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              {[["Case",detail.caseNumber],["Uploaded By",detail.uploadedBy],["Date",detail.uploadDate],["Size",detail.size],["Type",detail.type],["Chain",detail.chain]].map(([l,v]) => (
                <div key={l} className="bg-slate-800/50 rounded-lg p-3">
                  <p className="text-xs text-slate-500 mb-1">{l}</p>
                  <p className="text-slate-200 capitalize">{v}</p>
                </div>
              ))}
            </div>
            <div className="bg-slate-800 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-1.5">SHA-256 Hash</p>
              <p className="text-xs font-mono text-cyan-400 break-all">{detail.hash}</p>
            </div>
            <div className="bg-emerald-900/20 border border-emerald-500/20 rounded-xl p-4">
              <p className="text-xs font-bold text-emerald-400 mb-1">⛓ LEGyC Chain Status: {detail.chain}</p>
              <p className="text-xs text-slate-400">Block confirmed · Immutable · Court-admissible</p>
              <p className="text-xs font-mono text-slate-500 mt-1">Node: {NODE_ID} · Segment: {detail.id}</p>
            </div>
            <div className="flex gap-3">
              <Btn className="flex-1" onClick={() => alert("Downloading…")}>⬇ Download</Btn>
              <Btn variant="secondary" onClick={() => setDetail(null)}>Close</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

const MockTrialView = ({ tr }) => {
  const [scenario, setScenario] = useState("arraignment");
  const [running, setRunning]   = useState(false);
  const [log, setLog]           = useState([]);
  const [aiJudge, setAiJudge]   = useState(false);

  const SCENARIOS = [
    { id:"arraignment", label:"Arraignment",       difficulty:"Beginner",    desc:"Standard criminal arraignment procedure with plea entry." },
    { id:"bond",        label:"Bond Hearing",       difficulty:"Intermediate",desc:"Contested bail hearing with state and defense arguments." },
    { id:"motion",      label:"Motion to Suppress", difficulty:"Advanced",    desc:"Fourth Amendment suppression hearing with evidence rules." },
    { id:"trial",       label:"Full Criminal Trial",difficulty:"Expert",      desc:"Complete jury trial from voir dire to verdict." },
  ];

  const DIFF_COLOR = { Beginner:"text-emerald-400", Intermediate:"text-amber-400", Advanced:"text-orange-400", Expert:"text-red-400" };

  const start = () => {
    setRunning(true);
    const sc = SCENARIOS.find(s => s.id === scenario);
    setLog([
      `🎭 Mock session initialized — ${new Date().toLocaleTimeString()}`,
      `📋 Scenario: ${sc.label} (${sc.difficulty})`,
      `🤖 AI Judge ready${aiJudge ? " — will respond to proceedings" : " — observer mode"}`,
      `👥 Participants: You (Clerk), Student A (Defense), Student B (State)`,
      `📡 Session recording enabled — TotalRecall logging active`,
      `⏳ Waiting for participants to join courtroom…`,
    ]);
    tr.append("Mock Session Started: " + sc.label, "MockLab", "EDU");
  };

  return (
    <div>
      <SectionHead title="Mock Trial Lab" subtitle="AI-powered courtroom training and simulation" />
      <div className="grid grid-cols-2 gap-3 mb-5">
        {SCENARIOS.map(s => (
          <Card key={s.id} onClick={() => setScenario(s.id)} highlight={scenario === s.id}>
            <div className="flex justify-between items-start mb-1">
              <h4 className="font-semibold">{s.label}</h4>
              {scenario === s.id && <Badge variant="mock">Selected</Badge>}
            </div>
            <p className={`text-xs font-semibold ${DIFF_COLOR[s.difficulty]}`}>{s.difficulty}</p>
            <p className="text-xs text-slate-500 mt-1">{s.desc}</p>
          </Card>
        ))}
      </div>

      <Card>
        <div className="flex justify-between items-center mb-4 flex-wrap gap-3">
          <h3 className="font-bold">Session Console</h3>
          <div className="flex gap-3 items-center">
            <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
              <input type="checkbox" className="accent-cyan-500" checked={aiJudge} onChange={e => setAiJudge(e.target.checked)} />
              AI Judge Active
            </label>
            {!running
              ? <Btn onClick={start}>▶ Start Session</Btn>
              : <Btn variant="danger" onClick={() => { setRunning(false); setLog(l => [...l, "⏹ Session ended by clerk."]); }}>⏹ End Session</Btn>
            }
          </div>
        </div>
        <div className="bg-slate-950 rounded-xl p-4 min-h-48 font-mono text-xs space-y-1.5 border border-slate-800">
          {log.length === 0 && <p className="text-slate-700">Select a scenario and press Start…</p>}
          {log.map((l, i) => <p key={i} className={l.startsWith("🤖") ? "text-purple-400" : l.startsWith("❌") ? "text-red-400" : "text-green-400"}>{l}</p>)}
          {running && <p className="text-cyan-400 animate-pulse">▋</p>}
        </div>
      </Card>
    </div>
  );
};

const AISyncView = ({ wsStatus }) => (
  <div>
    <SectionHead title="AI / GTP Sync" subtitle="Constellation25 planetary agent integration and chain state" />
    <div className="grid grid-cols-3 gap-4 mb-6">
      {[
        { label:"Pathos Engine",      status:"Online",   color:"text-green-400",  port:3100, agent:"Sol (8019)" },
        { label:"Mars Agent",         status:"Synced",   color:"text-cyan-400",   port:8004, agent:"Mars (8004)" },
        { label:"TotalRecall",        status:"Streaming",color:"text-blue-400",   port:8005, agent:"Earth (8003)" },
        { label:"FacePrintPay Bio",   status:"Online",   color:"text-teal-400",   port:8001, agent:"Mercury (8001)" },
        { label:"Stripe / Venus",     status:"Standby",  color:"text-amber-400",  port:8002, agent:"Venus (8002)" },
        { label:"WebSocket Gateway",  status:wsStatus,   color:wsStatus==="connected"?"text-green-400":"text-amber-400", port:8080, agent:"Bridge" },
      ].map((a, i) => (
        <Card key={i}>
          <div className="flex items-center gap-2 mb-2">
            <span className={`w-2 h-2 rounded-full bg-current ${a.color} ${a.status !== "Standby" ? "animate-pulse" : ""}`} />
            <p className="text-xs text-slate-500">{a.status}</p>
          </div>
          <p className="font-bold text-white">{a.label}</p>
          <p className="text-xs text-slate-600 mt-1">:{a.port} · {a.agent}</p>
        </Card>
      ))}
    </div>

    <Card>
      <h3 className="font-semibold mb-3">LEGyC Chain</h3>
      <div className="space-y-2">
        {[["Node ID",NODE_ID],["Build",BUILD_ID],["Version",APP_VERSION],["Chain Status","Canonical · Synchronized"],["WebSocket",wsStatus]].map(([l,v]) => (
          <div key={l} className="flex justify-between border-b border-slate-800 pb-2 text-sm">
            <span className="text-slate-500">{l}</span>
            <span className="text-cyan-400 font-mono text-xs">{v}</span>
          </div>
        ))}
      </div>
    </Card>
  </div>
);

const AuditView = ({ tr }) => (
  <div>
    <SectionHead title="TotalRecall / LEGyC Audit" subtitle="Immutable chain-of-custody log — append-only · SHA-256 hashed" />
    <div className="flex gap-2 mb-5 flex-wrap">
      <Badge variant="success" pulse>Streaming</Badge>
      <Badge variant="verified">⛓ Canonical · {NODE_ID}</Badge>
      <Badge variant="info">Build: {BUILD_ID}</Badge>
    </div>
    <div className="space-y-2">
      {tr.log.map(entry => (
        <Card key={entry.id} className="!py-3">
          <div className="flex items-start gap-4">
            <span className="text-xs font-mono text-slate-600 mt-0.5 shrink-0 w-16">{entry.ts}</span>
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">{entry.event}</p>
              <p className="text-xs text-slate-500">{entry.actor} · {entry.case}</p>
              <p className="text-xs font-mono text-slate-700 mt-0.5">{entry.segment}</p>
            </div>
            <p className="text-xs font-mono text-cyan-400 shrink-0">{entry.hash}</p>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

const NotificationsView = ({ notifications, setNotifications }) => {
  const ICONS = { biometric:"🔐", filing:"📎", chain:"⛓", sms:"📱", system:"⚙️", tyler:"🔗" };
  const unread = notifications.filter(n => !n.read);
  return (
    <div>
      <SectionHead title="Notifications" subtitle={`${unread.length} unread · ${notifications.length} total`}
        action={
          <Btn variant="secondary" size="sm" onClick={() => setNotifications(n => n.map(x => ({ ...x, read:true })))}>
            Mark All Read
          </Btn>
        }
      />
      <div className="space-y-2">
        {notifications.map(n => (
          <Card key={n.id} className={`!py-3 ${!n.read ? "border-cyan-700/40" : ""}`}
            onClick={() => setNotifications(ns => ns.map(x => x.id === n.id ? { ...x, read:true } : x))}>
            <div className="flex items-center gap-3">
              <span className="text-xl">{ICONS[n.type] ?? "🔔"}</span>
              {!n.read && <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />}
              <div className="flex-1">
                <p className="text-sm text-slate-200">{n.message}</p>
                <p className="text-xs text-slate-600 mt-0.5">{n.time}</p>
              </div>
              <Badge variant={n.level}>{n.level}</Badge>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// RIGHT PANEL
// ─────────────────────────────────────────────────────────────────────────────
const RightPanel = ({ notifications, liveSession, elapsed, wsStatus, tr }) => {
  const unread = notifications.filter(n => !n.read).length;
  return (
    <div className="w-64 bg-slate-900 border-l border-slate-800 flex flex-col overflow-y-auto shrink-0">
      <div className="p-4 border-b border-slate-800">
        <p className="text-xs text-slate-500 mb-0.5">Live Session Context</p>
        <p className="font-bold text-white">Hon. Alex Martinez</p>
        <p className="text-xs text-slate-500">Judge · Courtroom 4B</p>
        <div className="mt-2 flex gap-1 flex-wrap">
          <Badge variant="verified">✓ All Green</Badge>
          <Badge variant={`ws_${wsStatus}`} pulse={wsStatus==="connected"}>WS</Badge>
        </div>
      </div>

      <div className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* Live session */}
        {liveSession && (
          <div>
            <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">Active Session</p>
            <div className="bg-slate-800/80 rounded-xl p-3 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Chain Protected</span>
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse mt-0.5" />
              </div>
              <p className="text-green-400 font-mono">✓ LEGyC Active</p>
              <p className="text-green-400 font-mono text-sm font-bold">{fmtElapsed(elapsed)}</p>
              {liveSession.nextMatter && (
                <div className="pt-1.5 border-t border-slate-700">
                  <p className="text-slate-500">Next matter</p>
                  <p className="text-slate-300">{liveSession.nextMatter}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TotalRecall */}
        <div>
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">TotalRecall</p>
          <div className="bg-emerald-900/20 border border-emerald-500/20 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <p className="text-xs font-bold text-emerald-400">Streaming</p>
            </div>
            <p className="text-xs text-slate-500">Last hash:</p>
            <p className="text-xs font-mono text-cyan-400 break-all mt-0.5">{tr.hash}</p>
            <p className="text-xs text-emerald-400 mt-1">Updated {tr.ts}</p>
          </div>
        </div>

        {/* LEGyC */}
        <div>
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">LEGyC Chain</p>
          <div className="bg-cyan-900/20 border border-cyan-500/20 rounded-xl p-3">
            <div className="flex justify-between mb-1">
              <p className="text-xs font-bold text-cyan-400">Canonical</p>
              <Badge variant="verified" className="text-[10px]">✓</Badge>
            </div>
            <p className="text-xs font-mono text-slate-400">/dalton/session-01</p>
            <p className="text-xs text-slate-500 mt-1">Notarized</p>
          </div>
        </div>

        {/* CM/ECF */}
        <div>
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">CM/ECF & Tyler</p>
          <div className="bg-slate-800/50 border border-slate-700/40 rounded-xl p-3">
            <p className="text-xs font-bold text-cyan-400 mb-1">Connected</p>
            <p className="text-xs text-slate-500">Last sync: 08:57</p>
            <p className="text-xs text-slate-500">3 filings queued</p>
            <button className="text-xs text-cyan-400 hover:underline mt-1.5">View Queue →</button>
          </div>
        </div>

        {/* Biometric */}
        <div>
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">Biometric Gateway</p>
          <div className="bg-amber-900/20 border border-amber-500/20 rounded-xl p-3">
            <p className="text-xs font-bold text-amber-400 mb-1">Pending: 1</p>
            <p className="text-xs text-slate-500">Jordan · JailCourt · 09:45</p>
            <button className="text-xs text-cyan-400 hover:underline mt-1.5">Verify →</button>
          </div>
        </div>

        {/* Notifications summary */}
        <div>
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">Notifications</p>
          <p className="text-xs text-slate-400">{unread} unread · {notifications.length} total</p>
          <p className="text-xs text-slate-600 mt-0.5">+24 min SMS batch</p>
        </div>
      </div>

      {/* Footer build info */}
      <div className="p-4 border-t border-slate-800 text-xs text-slate-700 space-y-0.5">
        <p>v{APP_VERSION} · {BUILD_ID}</p>
        <p>Node: {NODE_ID}</p>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// APP ROOT
// ─────────────────────────────────────────────────────────────────────────────
export default function VideoCourts() {
  // State
  const [view, setView]         = useState("dashboard");
  const [sessions, setSessions] = useState(SESSIONS_INIT);
  const [cases, setCases]       = useState(CASES_INIT);
  const [evidence, setEvidence] = useState(EVIDENCE_INIT);
  const [notifications, setNotifications] = useState(NOTIFICATIONS_INIT);

  // Modals
  const [openSession, setOpenSession] = useState(null);
  const [modal, setModal]             = useState(null);
  const [caseDetail, setCaseDetail]   = useState(null);

  // Live session timer
  const [elapsed, setElapsed]       = useState(754);
  const [recording, setRecording]   = useState(true);
  const [videoProvider, setVideoProvider] = useState("SimpleWebRTC");

  // Hooks
  const tr = useTotalRecall();
  const { status: wsStatus } = useWebSocket(WS_URL, {
    onMessage: (msg) => { if (msg?.type === "audit") tr.append(msg.event, msg.actor, msg.case); },
  });

  // Tick live timer
  useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const liveSession = sessions.find(s => s.status === "live");
  const unread      = notifications.filter(n => !n.read).length;

  // ── Nav ──
  const NAV = [
    { id:"dashboard",     icon:"📊", label:"Dashboard" },
    { id:"cases",         icon:"📁", label:"Cases & Dockets" },
    { id:"hearings",      icon:"📅", label:"Hearings & Calendar" },
    { id:"jailcourt",     icon:"🏛",  label:"JailCourt" },
    { id:"evidence",      icon:"🔐", label:"Evidence Vault" },
    { id:"notifications", icon:"🔔", label:"Notifications", badge: unread || null },
  ];
  const NAV2 = [
    { id:"mock", icon:"🎭", label:"Mock Trial Lab" },
    { id:"ai",   icon:"🤖", label:"AI / GTP Sync" },
  ];
  const NAV3 = [
    { id:"audit", icon:"🛡", label:"TotalRecall / LEGyC" },
  ];

  const navLabel = (id) =>
    [...NAV,...NAV2,...NAV3].find(n => n.id === id)?.label ?? id;

  // ── CRUD handlers ──
  const addSession = (f) => {
    setSessions(s => [...s, {
      id:`s${Date.now()}`, ...f, status:"scheduled", elapsed:0,
      circuit:"3rd Judicial Circuit", participants:[f.judge], legyc:true, biometric:"N/A"
    }]);
    tr.append("Hearing Scheduled: " + f.title, "Clerk", f.caseNumber);
    setNotifications(n => [{ id:`n${Date.now()}`, level:"info", type:"filing", message:`Hearing scheduled: ${f.title} (${f.caseNumber})`, time: new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"}), read:false }, ...n]);
  };

  const addCase = (f) => {
    setCases(c => [...c, {
      id:`c${Date.now()}`, ...f, status:"active",
      filed: new Date().toISOString().split("T")[0], docket:0,
      attorneys: f.attorneys ? f.attorneys.split(",").map(a => a.trim()) : []
    }]);
    tr.append("Case Created: " + f.title, "Clerk", f.caseNumber);
  };

  const addEvidence = (f) => {
    const c = cases.find(x => x.id === f.caseId);
    setEvidence(e => [...e, {
      id:`e${Date.now()}`, ...f,
      caseNumber: c?.caseNumber ?? "—",
      hash: genHash(), status:"pending", size:"—",
      uploadDate: new Date().toISOString().split("T")[0], chain:"Pending"
    }]);
    tr.append("Evidence Uploaded: " + f.fileName, f.uploadedBy, c?.caseNumber ?? "—");
    setNotifications(n => [{ id:`n${Date.now()}`, level:"warn", type:"filing", message:`Evidence pending verification: ${f.fileName}`, time: new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"}), read:false }, ...n]);
  };

  // ── View renderer ──
  const renderView = () => {
    const shared = { sessions, cases, elapsed, onOpenSession: setOpenSession, onSchedule: () => setModal("schedule"), tr };
    switch (view) {
      case "dashboard":     return <DashboardView {...shared} />;
      case "cases":         return <CasesView cases={cases} onNewCase={() => setModal("newcase")} onViewCase={setCaseDetail} />;
      case "hearings":      return <HearingsView {...shared} />;
      case "jailcourt":     return <JailCourtView {...shared} />;
      case "evidence":      return <EvidenceView evidence={evidence} cases={cases} onUpload={() => setModal("upload")} tr={tr} />;
      case "notifications": return <NotificationsView notifications={notifications} setNotifications={setNotifications} />;
      case "mock":          return <MockTrialView tr={tr} />;
      case "ai":            return <AISyncView wsStatus={wsStatus} />;
      case "audit":         return <AuditView tr={tr} />;
      default: return null;
    }
  };

  const NavBtn = ({ item }) => (
    <button key={item.id} onClick={() => setView(item.id)}
      className={`w-full flex items-center justify-between px-4 py-2.5 text-sm transition-colors rounded-lg mx-1 my-0.5
        ${view === item.id ? "bg-slate-800 text-cyan-400" : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200"}`}
      style={{ width:"calc(100% - 8px)" }}>
      <span className="flex items-center gap-3"><span>{item.icon}</span><span>{item.label}</span></span>
      {item.badge ? <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">{item.badge}</span> : null}
    </button>
  );

  return (
    <div className="flex h-screen bg-slate-950 text-white overflow-hidden" style={{ fontFamily:"'Inter','SF Pro Display',system-ui,sans-serif" }}>

      {/* ── SIDEBAR ── */}
      <div className="w-60 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
        {/* Logo */}
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 via-cyan-400 to-amber-500 flex items-center justify-center text-base font-black shadow-lg shadow-cyan-900/40">V</div>
            <div>
              <h1 className="font-extrabold text-sm leading-tight tracking-tight">VideoCourts™</h1>
              <p className="text-xs text-slate-500">Judicial Session Console</p>
            </div>
          </div>
          <div className="flex gap-1.5 flex-wrap">
            <Badge variant="verified" pulse>Online</Badge>
            <Badge variant="default">MVP v{APP_VERSION}</Badge>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-2 overflow-y-auto px-1">
          <p className="text-[10px] text-slate-700 font-bold uppercase tracking-widest px-3 py-2">Navigation</p>
          {NAV.map(item => <NavBtn key={item.id} item={item} />)}

          <p className="text-[10px] text-slate-700 font-bold uppercase tracking-widest px-3 py-2 mt-3">Education & AI</p>
          {NAV2.map(item => <NavBtn key={item.id} item={item} />)}

          <p className="text-[10px] text-slate-700 font-bold uppercase tracking-widest px-3 py-2 mt-3">Compliance</p>
          {NAV3.map(item => <NavBtn key={item.id} item={item} />)}
        </nav>

        {/* Chain footer */}
        <div className="p-4 border-t border-slate-800 text-xs">
          <div className="flex justify-between text-slate-500 mb-0.5">
            <span>LEGyC Chain</span>
            <span className="text-emerald-400 font-semibold">Synced</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Node</span>
            <span className="font-mono">{NODE_ID}</span>
          </div>
          <button className="text-cyan-400 hover:underline text-xs mt-1.5" onClick={() => setView("audit")}>View Audit Log →</button>
        </div>
      </div>

      {/* ── MAIN ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="bg-slate-900 border-b border-slate-800 px-7 py-4 flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-lg font-extrabold tracking-tight">{navLabel(view)}</h2>
            {liveSession && (
              <div className="flex items-center gap-2 mt-0.5">
                <Badge variant="live" pulse>LIVE</Badge>
                <span className="text-xs text-slate-500">{liveSession.title} · {fmtElapsed(elapsed)}</span>
              </div>
            )}
          </div>
          <div className="flex gap-2">
            {view === "dashboard"     && <Btn size="sm" onClick={() => setModal("schedule")}>+ Schedule Hearing</Btn>}
            {view === "cases"         && <Btn size="sm" onClick={() => setModal("newcase")}>+ New Case</Btn>}
            {view === "evidence"      && <Btn size="sm" onClick={() => setModal("upload")}>+ Upload Evidence</Btn>}
            {view === "hearings"      && <Btn size="sm" onClick={() => setModal("schedule")}>+ Schedule Hearing</Btn>}
            {liveSession && (
              <Btn size="sm" variant="danger" onClick={() => setOpenSession(liveSession)}>
                🔴 {fmtElapsed(elapsed)} · Join Live
              </Btn>
            )}
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-7">{renderView()}</main>

        {/* Footer */}
        <footer className="bg-slate-900 border-t border-slate-800 px-7 py-2 flex justify-between items-center text-xs text-slate-700 shrink-0">
          <span>Court-grade recording · TotalRecall & LEGyC enforced · FacePrintPay biometric</span>
          <span>All participants consent to recording and biometric identity checks.</span>
          <span>© FacePrintPay Inc · Build {BUILD_ID}</span>
        </footer>
      </div>

      {/* ── RIGHT PANEL ── */}
      <RightPanel notifications={notifications} liveSession={liveSession} elapsed={elapsed} wsStatus={wsStatus} tr={tr} />

      {/* ── MODALS ── */}
      {openSession && (
        <LiveSessionPanel
          session={openSession} elapsed={elapsed}
          recording={recording} setRecording={setRecording}
          videoProvider={videoProvider} setVideoProvider={setVideoProvider}
          tr={tr} onClose={() => setOpenSession(null)}
        />
      )}
      {modal === "schedule" && <ScheduleModal onClose={() => setModal(null)} onSave={addSession} />}
      {modal === "newcase"  && <NewCaseModal  onClose={() => setModal(null)} onSave={addCase}    />}
      {modal === "upload"   && <UploadModal   cases={cases} onClose={() => setModal(null)} onSave={addEvidence} />}
      {caseDetail && <CaseDetailModal c={caseDetail} onClose={() => setCaseDetail(null)} onSchedule={() => setModal("schedule")} />}
    </div>
  );
}
